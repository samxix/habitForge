import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { archiveHabit, updateHabit } from "@/actions/habits";
import { Heatmap } from "@/components/Heatmap";
import { HabitForm } from "@/components/HabitForm";
import { addDays, todayIn } from "@/lib/dates";
import { toView } from "@/lib/habits";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { computeStreaks } from "@/lib/streak";

export const metadata: Metadata = { title: "Edit habit" };

export default async function EditHabitPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser();
  const today = todayIn(user.timezone);

  const row = await prisma.habit.findFirst({
    where: { id, userId: user.id, archivedAt: null },
    include: { checkIns: { where: { date: { gte: new Date(`${addDays(today, -400)}T00:00:00Z`) } }, select: { date: true } } },
  });
  if (!row) notFound();

  const habit = toView(row);
  const { current, longest } = computeStreaks({ ...habit, today });
  const heat = Object.fromEntries(habit.checkIns.map((d) => [d, 1]));

  return (
    <div className="max-w-2xl space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">{habit.title}</h1>

      <section className="panel space-y-4 p-5">
        <p className="text-sm tabular-nums text-zinc-500">
          <span className="text-xl font-bold text-amber-600 dark:text-amber-400">{current}</span> current streak ·{" "}
          <span className="font-semibold text-zinc-900 dark:text-zinc-100">{longest}</span> best
        </p>
        <Heatmap data={heat} max={1} end={today} unit="completed" />
      </section>

      <section className="panel p-6">
        <h2 className="mb-4 font-semibold">Edit habit</h2>
        <HabitForm action={updateHabit.bind(null, habit.id)} initial={habit} />
      </section>

      <form action={archiveHabit.bind(null, habit.id)}>
        <button className="text-sm text-red-600 underline dark:text-red-400">Archive this habit</button>
        <p className="mt-1 text-xs text-zinc-500">Archived habits disappear from your lists. Your history is kept.</p>
      </form>
    </div>
  );
}
