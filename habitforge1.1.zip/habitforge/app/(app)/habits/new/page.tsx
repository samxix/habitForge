import type { Metadata } from "next";
import { createHabit } from "@/actions/habits";
import { HabitForm } from "@/components/HabitForm";

export const metadata: Metadata = { title: "New habit" };

export default function NewHabitPage() {
  return (
    <div className="max-w-lg space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">New habit</h1>
      <div className="panel p-6">
        <HabitForm action={createHabit} />
      </div>
    </div>
  );
}
