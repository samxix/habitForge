import type { Metadata } from "next";
import Link from "next/link";
import { addDays, todayIn } from "@/lib/dates";
import { scheduleLabel, toView } from "@/lib/habits";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { computeStreaks } from "@/lib/streak";

export const metadata: Metadata = { title: "Habits" };

export default async function HabitsPage() {
  const user = await requireUser();
  const today = todayIn(user.timezone);
  const habits = (
    await prisma.habit.findMany({
      where: { userId: user.id, archivedAt: null },
      include: { checkIns: { where: { date: { gte: new Date(`${addDays(today, -400)}T00:00:00Z`) } }, select: { date: true } } },
      orderBy: { createdAt: "asc" },
    })
  ).map(toView);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Habits</h1>
        <Link href="/habits/new" className="btn">
          New habit
        </Link>
      </div>

      {habits.length === 0 ? (
        <p className="panel p-8 text-center text-zinc-500">No habits yet. Create one to get started.</p>
      ) : (
        <ul className="panel divide-y divide-zinc-200 dark:divide-zinc-800">
          {habits.map((h) => {
            const { current, longest } = computeStreaks({ ...h, today });
            return (
              <li key={h.id}>
                <Link href={`/habits/${h.id}`} className="flex items-center gap-4 p-4 transition hover:bg-zinc-50 dark:hover:bg-zinc-900">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{h.title}</p>
                    <p className="text-sm text-zinc-500">{scheduleLabel(h.daysOfWeek)}</p>
                  </div>
                  <p className="text-right text-sm tabular-nums text-zinc-500">
                    {current} current · {longest} best
                  </p>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
