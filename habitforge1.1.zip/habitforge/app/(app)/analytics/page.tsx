import type { Metadata } from "next";
import Link from "next/link";
import { WeeklyChart } from "@/components/WeeklyChart";
import { addDays, todayIn } from "@/lib/dates";
import { toView } from "@/lib/habits";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { rangeStats, weeklySeries } from "@/lib/stats";
import { computeStreaks } from "@/lib/streak";

export const metadata: Metadata = { title: "Analytics" };

export default async function AnalyticsPage() {
  const user = await requireUser();
  const today = todayIn(user.timezone);
  const from30 = addDays(today, -29);

  const habits = (
    await prisma.habit.findMany({
      where: { userId: user.id, archivedAt: null },
      include: { checkIns: { where: { date: { gte: new Date(`${addDays(today, -400)}T00:00:00Z`) } }, select: { date: true } } },
      orderBy: { createdAt: "asc" },
    })
  ).map(toView);

  if (habits.length === 0) {
    return (
      <div className="space-y-4">
        <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
        <p className="panel p-8 text-center text-zinc-500">
          Charts appear once you have a habit. <Link href="/habits/new" className="underline">Create one</Link>.
        </p>
      </div>
    );
  }

  const rows = habits.map((h) => {
    const s = rangeStats(h, from30, today);
    const streaks = computeStreaks({ ...h, today });
    return { h, ...s, rate: s.due ? Math.round((s.completed / s.due) * 100) : 0, ...streaks };
  });
  const totalDue = rows.reduce((n, r) => n + r.due, 0);
  const totalDone = rows.reduce((n, r) => n + r.completed, 0);
  const rate30 = totalDue ? Math.round((totalDone / totalDue) * 100) : 0;
  const bestStreak = Math.max(...rows.map((r) => r.current));

  const stats = [
    { label: "Completion, last 30 days", value: `${rate30}%` },
    { label: "Check-ins, last 30 days", value: String(totalDone) },
    { label: "Longest running streak", value: `${bestStreak} ${bestStreak === 1 ? "day" : "days"}` },
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>

      <dl className="grid gap-3 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="panel p-4">
            <dd className="text-3xl font-bold tabular-nums text-amber-600 dark:text-amber-400">{s.value}</dd>
            <dt className="mt-1 text-sm text-zinc-500">{s.label}</dt>
          </div>
        ))}
      </dl>

      <section className="panel p-5">
        <h2 className="mb-4 font-semibold">Weekly completion</h2>
        <WeeklyChart data={weeklySeries(habits, today, 8)} />
      </section>

      <section className="panel p-5">
        <h2 className="mb-4 font-semibold">By habit, last 30 days</h2>
        <ul className="space-y-4">
          {rows.map((r) => (
            <li key={r.h.id}>
              <div className="mb-1.5 flex items-baseline justify-between gap-3 text-sm">
                <span className="truncate font-medium">{r.h.title}</span>
                <span className="shrink-0 tabular-nums text-zinc-500">
                  {r.rate}% · {r.current} current · {r.longest} best
                </span>
              </div>
              <div
                role="progressbar"
                aria-valuenow={r.rate}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`${r.h.title} completion`}
                className="h-2 overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-800"
              >
                <div className="h-full rounded-full bg-amber-500" style={{ width: `${r.rate}%` }} />
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
