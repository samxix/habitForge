import type { Metadata } from "next";
import { ProfileForm } from "@/components/ProfileForm";
import { requireUser } from "@/lib/session";

export const metadata: Metadata = { title: "Profile" };

export default async function ProfilePage() {
  const user = await requireUser();
  const zones = Intl.supportedValuesOf("timeZone");
  const timezones = zones.includes(user.timezone) ? zones : [user.timezone, ...zones];

  return (
    <div className="max-w-lg space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Profile</h1>
      <div className="panel p-6">
        <ProfileForm name={user.name} email={user.email} timezone={user.timezone} timezones={timezones} />
      </div>
    </div>
  );
}
