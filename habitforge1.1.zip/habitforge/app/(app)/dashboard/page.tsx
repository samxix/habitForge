import type { Metadata } from "next";
import Link from "next/link";
import { Heatmap } from "@/components/Heatmap";
import { HabitToggle } from "@/components/HabitToggle";
import { addDays, formatDay, todayIn, weekday } from "@/lib/dates";
import { scheduleLabel, toView } from "@/lib/habits";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { computeStreaks } from "@/lib/streak";

export const metadata: Metadata = { title: "Today" };

export default async function Dashboard() {
  const user = await requireUser();
  const today = todayIn(user.timezone);

  const habits = (
    await prisma.habit.findMany({
      where: { userId: user.id, archivedAt: null },
      include: { checkIns: { where: { date: { gte: new Date(`${addDays(today, -400)}T00:00:00Z`) } }, select: { date: true } } },
      orderBy: { createdAt: "asc" },
    })
  ).map(toView);

  const dueToday = habits.filter((h) => h.daysOfWeek.includes(weekday(today)));
  const rest = habits.filter((h) => !h.daysOfWeek.includes(weekday(today)));
  const doneToday = dueToday.filter((h) => h.checkIns.includes(today)).length;

  const heat: Record<string, number> = {};
  for (const h of habits) for (const d of h.checkIns) heat[d] = (heat[d] ?? 0) + 1;

  const streakOf = (h: (typeof habits)[number]) => computeStreaks({ ...h, today }).current;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">
          {formatDay(today, { weekday: "long", month: "long", day: "numeric" })}
        </h1>
        <p className="mt-1 text-zinc-600 dark:text-zinc-400">
          {dueToday.length === 0
            ? "Nothing is scheduled today."
            : doneToday === dueToday.length
              ? "Everything for today is done."
              : `${doneToday} of ${dueToday.length} done today.`}
        </p>
      </div>

      {habits.length === 0 ? (
        <div className="panel p-8 text-center">
          <p className="font-medium">You have no habits yet.</p>
          <p className="mt-1 text-sm text-zinc-500">Create your first habit to start a streak.</p>
          <Link href="/habits/new" className="btn mt-4">
            Create a habit
          </Link>
        </div>
      ) : (
        <>
          <ul className="panel divide-y divide-zinc-200 dark:divide-zinc-800">
            {dueToday.map((h) => {
              const streak = streakOf(h);
              return (
                <li key={h.id} className="flex items-center gap-4 p-4">
                  <HabitToggle habitId={h.id} date={today} done={h.checkIns.includes(today)} title={h.title} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{h.title}</p>
                    <p className="text-sm text-zinc-500">{scheduleLabel(h.daysOfWeek)}</p>
                  </div>
                  <p className="text-right text-sm tabular-nums text-zinc-500">
                    <span className="text-lg font-bold text-amber-600 dark:text-amber-400">{streak}</span>{" "}
                    {streak === 1 ? "day" : "days"}
                  </p>
                </li>
              );
            })}
            {dueToday.length === 0 && <li className="p-4 text-sm text-zinc-500">Enjoy the day off.</li>}
          </ul>

          {rest.length > 0 && (
            <div>
              <h2 className="mb-2 text-sm font-medium text-zinc-500">Not scheduled today</h2>
              <ul className="space-y-1 text-sm text-zinc-600 dark:text-zinc-400">
                {rest.map((h) => (
                  <li key={h.id}>
                    {h.title} <span className="text-zinc-400">· {scheduleLabel(h.daysOfWeek)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <section className="panel p-5">
            <h2 className="mb-4 font-semibold">Last 26 weeks</h2>
            <Heatmap data={heat} max={habits.length} end={today} />
          </section>
        </>
      )}
    </div>
  );
}
