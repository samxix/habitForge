import Link from "next/link";
import { logout } from "@/actions/auth";
import { NavLinks } from "@/components/NavLinks";
import { ThemeToggle } from "@/components/ThemeToggle";
import { requireUser } from "@/lib/session";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  await requireUser();
  return (
    <div className="mx-auto max-w-4xl px-5 pb-16">
      <header className="flex flex-wrap items-center justify-between gap-3 py-4">
        <Link href="/dashboard" className="text-lg font-bold tracking-tight">
          HabitForge
        </Link>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <form action={logout}>
            <button className="btn-quiet h-9">Sign out</button>
          </form>
        </div>
        <div className="w-full sm:order-none sm:w-auto sm:flex-1 sm:px-6">
          <NavLinks />
        </div>
      </header>
      <main className="pt-4">{children}</main>
    </div>
  );
}
