import type { Metadata } from "next";
import { AuthForm } from "@/components/AuthForm";

export const metadata: Metadata = { title: "Create account" };

export default function RegisterPage() {
  return (
    <>
      <h1 className="mb-5 text-2xl font-bold tracking-tight">Create your account</h1>
      <AuthForm mode="register" />
    </>
  );
}
