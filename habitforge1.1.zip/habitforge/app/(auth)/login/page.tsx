import type { Metadata } from "next";
import { AuthForm } from "@/components/AuthForm";

export const metadata: Metadata = { title: "Sign in" };

export default function LoginPage() {
  return (
    <>
      <h1 className="mb-5 text-2xl font-bold tracking-tight">Sign in</h1>
      <AuthForm mode="login" />
    </>
  );
}
