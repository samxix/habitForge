import Link from "next/link";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col px-5">
      <header className="flex items-center justify-between py-5">
        <Link href="/" className="text-lg font-bold tracking-tight">
          HabitForge
        </Link>
        <ThemeToggle />
      </header>
      <div className="flex flex-1 items-center pb-16">
        <div className="panel w-full p-6">{children}</div>
      </div>
    </main>
  );
}
