import Link from "next/link";
import { Heatmap } from "@/components/Heatmap";
import { ThemeToggle } from "@/components/ThemeToggle";
import { addDays } from "@/lib/dates";

// Deterministic sample data so the landing page heatmap renders the same on every load.
function sample(end: string) {
  const data: Record<string, number> = {};
  for (let i = 0; i < 26 * 7; i++) {
    const v = (Math.sin(i * 12.9898) * 43758.5453) % 1;
    const r = Math.abs(v);
    const ramp = Math.min(1, i / 120 + 0.25);
    data[addDays(end, -i)] = r < ramp ? Math.ceil(r * 4 * (ramp + 0.3)) % 5 : 0;
  }
  return data;
}

export default function Landing() {
  const end = "2026-10-18";
  return (
    <main className="mx-auto flex min-h-screen max-w-5xl flex-col px-5">
      <header className="flex items-center justify-between py-5">
        <span className="text-lg font-bold tracking-tight">HabitForge</span>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link href="/login" className="btn-quiet">
            Sign in
          </Link>
        </div>
      </header>

      <section className="flex flex-1 flex-col justify-center gap-10 py-12">
        <div className="max-w-2xl space-y-5">
          <h1 className="text-5xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">
            Do the small thing. Every day it counts.
          </h1>
          <p className="max-w-xl text-lg text-zinc-600 dark:text-zinc-400">
            Schedule your habits, check them off in a tap, and watch your calendar heat up as the streak grows.
          </p>
          <div className="flex gap-3">
            <Link href="/register" className="btn">
              Start tracking
            </Link>
            <Link href="/login" className="btn-quiet">
              Sign in
            </Link>
          </div>
        </div>

        <div className="panel p-5">
          <Heatmap data={sample(end)} max={4} end={end} unit="habits done" />
        </div>
      </section>
    </main>
  );
}
