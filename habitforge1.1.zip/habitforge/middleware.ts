import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE, verifyToken } from "@/lib/token";

const PROTECTED = ["/dashboard", "/habits", "/analytics", "/profile"];
const GUEST_ONLY = ["/login", "/register"];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const userId = await verifyToken(req.cookies.get(SESSION_COOKIE)?.value);

  if (!userId && PROTECTED.some((p) => pathname.startsWith(p))) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (userId && GUEST_ONLY.includes(pathname)) {
    return NextResponse.redirect(new URL("/dashboard", req.url));
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/habits/:path*", "/analytics/:path*", "/profile/:path*", "/login", "/register"],
};
