import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const iso = (d: Date) => d.toISOString().slice(0, 10);
const addDays = (s: string, n: number) => {
  const d = new Date(`${s}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return iso(d);
};

async function main() {
  const email = "demo@habitforge.dev";
  await prisma.user.deleteMany({ where: { email } });

  const today = iso(new Date());
  const start = addDays(today, -120);
  const user = await prisma.user.create({
    data: { email, name: "Demo User", timezone: "UTC", password: await bcrypt.hash("demo12345", 12) },
  });

  const defs = [
    { title: "Read for 20 minutes", days: [0, 1, 2, 3, 4, 5, 6], p: 0.8 },
    { title: "Workout", days: [1, 3, 5], p: 0.75 },
    { title: "Write in journal", days: [1, 2, 3, 4, 5], p: 0.6 },
  ];

  let seed = 7;
  const rand = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);

  for (const def of defs) {
    const habit = await prisma.habit.create({
      data: {
        userId: user.id,
        title: def.title,
        daysOfWeek: def.days,
        startDate: new Date(`${start}T00:00:00Z`),
      },
    });
    const rows = [];
    for (let d = start; d <= today; d = addDays(d, 1)) {
      const wd = new Date(`${d}T00:00:00Z`).getUTCDay();
      if (def.days.includes(wd) && rand() < def.p) {
        rows.push({ habitId: habit.id, date: new Date(`${d}T00:00:00Z`) });
      }
    }
    await prisma.checkIn.createMany({ data: rows });
  }
  console.log(`Seeded ${email} / demo12345`);
}

main().finally(() => prisma.$disconnect());
