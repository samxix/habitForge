# HabitForge

A full-stack habit tracker: email auth, scheduled habits, daily check-ins, streaks, a calendar heatmap, weekly analytics and dark mode.

**Stack:** Next.js 15 (App Router) · TypeScript · Tailwind CSS · Prisma · PostgreSQL

## Run it

```bash
npm install
cp .env.example .env        # set DATABASE_URL and AUTH_SECRET (openssl rand -base64 32)
npx prisma migrate dev --name init
npm run db:seed             # optional: demo@habitforge.dev / demo12345
npm run dev
```

Open http://localhost:3000. Run `npm test` for the streak unit tests.

## How it works

- **Auth:** bcrypt-hashed passwords, a signed JWT in an httpOnly cookie, `middleware.ts` guarding `/dashboard`, `/habits`, `/analytics` and `/profile`. Every page and server action also calls `requireUser()`, and every query filters by `userId`.
- **Days, not timestamps:** a check-in is a `Date` for the user's local calendar day, using the timezone on their profile. `@@unique([habitId, date])` allows one check-in per habit per day.
- **Streaks are derived:** `lib/streak.ts` computes them from the schedule and check-ins, so they can't go stale. Unscheduled days never break a streak, and an unchecked today doesn't either.
- **Analytics:** `lib/stats.ts` computes completion against the days a habit was actually due.

## Deploy

1. Create a Postgres database (Neon, Supabase, Railway).
2. Push to GitHub and import into Vercel; set `DATABASE_URL` and `AUTH_SECRET`.
3. Run `npx prisma migrate deploy` against the production database.

## Project layout

```
app/(auth)        login, register
app/(app)         dashboard, habits, analytics, profile (protected)
actions/          server actions (auth, habits, check-ins)
components/       heatmap, toggle, forms, chart
lib/              dates, streak logic + tests, stats, session, prisma
prisma/           schema and seed
```

## Next steps

Email verification and password reset (Resend), rate limiting on login, and date-range queries for analytics once a user has years of history.
