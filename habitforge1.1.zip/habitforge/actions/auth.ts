"use server";

import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { z } from "zod";
import { isValidTimezone } from "@/lib/dates";
import { prisma } from "@/lib/prisma";
import { createSession, destroySession, requireUser } from "@/lib/session";
import type { FormState } from "@/lib/types";

const email = z.string().trim().toLowerCase().email("Enter a valid email address.");
const password = z.string().min(8, "Use at least 8 characters.").max(72, "Use 72 characters or fewer.");

const registerSchema = z.object({
  name: z.string().trim().min(1, "Enter your name.").max(60),
  email,
  password,
  timezone: z.string().optional(),
});

export async function register(_: FormState, fd: FormData): Promise<FormState> {
  const parsed = registerSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const { name, email, password, timezone } = parsed.data;
  if (await prisma.user.findUnique({ where: { email } })) {
    return { error: "An account with this email already exists. Sign in instead." };
  }

  const user = await prisma.user.create({
    data: {
      name,
      email,
      password: await bcrypt.hash(password, 12),
      timezone: timezone && isValidTimezone(timezone) ? timezone : "UTC",
    },
  });
  await createSession(user.id);
  redirect("/dashboard");
}

const loginSchema = z.object({ email, password: z.string().min(1, "Enter your password.") });

export async function login(_: FormState, fd: FormData): Promise<FormState> {
  const parsed = loginSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const user = await prisma.user.findUnique({ where: { email: parsed.data.email } });
  const ok = user && (await bcrypt.compare(parsed.data.password, user.password));
  if (!user || !ok) return { error: "Email or password is incorrect." };

  await createSession(user.id);
  redirect("/dashboard");
}

export async function logout() {
  await destroySession();
  redirect("/login");
}

const profileSchema = z.object({
  name: z.string().trim().min(1, "Enter your name.").max(60),
  timezone: z.string().refine(isValidTimezone, "Choose a valid timezone."),
});

export async function updateProfile(_: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const parsed = profileSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  await prisma.user.update({ where: { id: user.id }, data: parsed.data });
  return { ok: true };
}
