"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { addDays, todayIn, toDate } from "@/lib/dates";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import type { FormState } from "@/lib/types";

const habitSchema = z.object({
  title: z.string().trim().min(1, "Give the habit a name.").max(80, "Use 80 characters or fewer."),
  description: z.string().trim().max(300, "Use 300 characters or fewer.").optional(),
  days: z
    .array(z.coerce.number().int().min(0).max(6))
    .min(1, "Pick at least one day.")
    .transform((d) => [...new Set(d)].sort((a, b) => a - b)),
});

function parseHabit(fd: FormData) {
  return habitSchema.safeParse({
    title: fd.get("title"),
    description: fd.get("description") || undefined,
    days: fd.getAll("days"),
  });
}

function refresh() {
  revalidatePath("/", "layout");
}

export async function createHabit(_: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const parsed = parseHabit(fd);
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const { title, description, days } = parsed.data;
  await prisma.habit.create({
    data: {
      userId: user.id,
      title,
      description,
      daysOfWeek: days,
      startDate: toDate(todayIn(user.timezone)),
    },
  });
  refresh();
  redirect("/habits");
}

export async function updateHabit(id: string, _: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const parsed = parseHabit(fd);
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const { title, description, days } = parsed.data;
  // userId in the where clause means one user can never edit another's habit.
  const res = await prisma.habit.updateMany({
    where: { id, userId: user.id },
    data: { title, description: description ?? null, daysOfWeek: days },
  });
  if (res.count === 0) return { error: "Habit not found." };
  refresh();
  redirect("/habits");
}

export async function archiveHabit(id: string) {
  const user = await requireUser();
  await prisma.habit.updateMany({ where: { id, userId: user.id }, data: { archivedAt: new Date() } });
  refresh();
  redirect("/habits");
}

/** Toggles a check-in for today or one of the previous 7 days. */
export async function toggleCheckIn(habitId: string, date: string) {
  const user = await requireUser();
  const today = todayIn(user.timezone);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > today || date < addDays(today, -7)) {
    throw new Error("You can only check in for today or the past week.");
  }

  const habit = await prisma.habit.findFirst({ where: { id: habitId, userId: user.id, archivedAt: null } });
  if (!habit) throw new Error("Habit not found.");

  const where = { habitId_date: { habitId, date: toDate(date) } };
  const existing = await prisma.checkIn.findUnique({ where });
  if (existing) await prisma.checkIn.delete({ where });
  else await prisma.checkIn.create({ data: { habitId, date: toDate(date) } });

  revalidatePath("/dashboard");
  revalidatePath("/analytics");
  revalidatePath("/habits");
}
