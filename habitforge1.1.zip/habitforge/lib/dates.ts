// All "days" in HabitForge are plain YYYY-MM-DD strings in the user's own timezone.

export function todayIn(tz: string, now = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
}

export const toDate = (s: string) => new Date(`${s}T00:00:00.000Z`);
export const toStr = (d: Date) => d.toISOString().slice(0, 10);

export function addDays(s: string, n: number): string {
  const d = toDate(s);
  d.setUTCDate(d.getUTCDate() + n);
  return toStr(d);
}

/** 0 = Sunday ... 6 = Saturday */
export const weekday = (s: string) => toDate(s).getUTCDay();

export function formatDay(s: string, opts: Intl.DateTimeFormatOptions): string {
  return toDate(s).toLocaleDateString("en-US", { ...opts, timeZone: "UTC" });
}

export function isValidTimezone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat("en-CA", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}
