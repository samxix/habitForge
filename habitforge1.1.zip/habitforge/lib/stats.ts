import { addDays, formatDay, weekday } from "./dates";
import type { HabitView } from "./habits";

type Schedule = Pick<HabitView, "daysOfWeek" | "startDate" | "checkIns">;

export function dueDaysIn(h: Schedule, from: string, to: string): string[] {
  const start = h.startDate > from ? h.startDate : from;
  const out: string[] = [];
  for (let d = start; d <= to; d = addDays(d, 1)) {
    if (h.daysOfWeek.includes(weekday(d))) out.push(d);
  }
  return out;
}

export function rangeStats(h: Schedule, from: string, to: string) {
  const done = new Set(h.checkIns);
  const due = dueDaysIn(h, from, to);
  return { due: due.length, completed: due.filter((d) => done.has(d)).length };
}

export function weeklySeries(habits: Schedule[], today: string, weeks = 8) {
  const out: { label: string; rate: number; completed: number; due: number }[] = [];
  for (let i = weeks - 1; i >= 0; i--) {
    const to = addDays(today, -7 * i);
    const from = addDays(to, -6);
    let due = 0;
    let completed = 0;
    for (const h of habits) {
      const s = rangeStats(h, from, to);
      due += s.due;
      completed += s.completed;
    }
    out.push({
      label: formatDay(from, { month: "short", day: "numeric" }),
      rate: due === 0 ? 0 : Math.round((completed / due) * 100),
      completed,
      due,
    });
  }
  return out;
}
