import { addDays, weekday } from "./dates";

export type StreakInput = {
  /** Weekdays the habit is due, 0 = Sunday ... 6 = Saturday */
  daysOfWeek: number[];
  /** First day the habit counts (YYYY-MM-DD) */
  startDate: string;
  /** Days with a check-in (YYYY-MM-DD) */
  checkIns: Iterable<string>;
  /** The user's current local day (YYYY-MM-DD) */
  today: string;
};

/**
 * Streaks count consecutive *scheduled* days that were completed.
 * - Days the habit isn't scheduled never break a streak.
 * - Today being unchecked doesn't break it yet; the day isn't over.
 * - Streaks are always derived, never stored, so edits to past check-ins stay consistent.
 */
export function computeStreaks({ daysOfWeek, startDate, checkIns, today }: StreakInput) {
  const done = new Set(checkIns);
  const scheduled = (d: string) => daysOfWeek.includes(weekday(d));

  let longest = 0;
  let run = 0;
  for (let d = startDate; d <= today; d = addDays(d, 1)) {
    if (!scheduled(d)) continue;
    if (done.has(d)) {
      run += 1;
      longest = Math.max(longest, run);
    } else if (d !== today) {
      run = 0;
    }
  }

  let current = 0;
  for (let d = today; d >= startDate; d = addDays(d, -1)) {
    if (!scheduled(d)) continue;
    if (done.has(d)) current += 1;
    else if (d === today) continue;
    else break;
  }

  return { current, longest };
}
