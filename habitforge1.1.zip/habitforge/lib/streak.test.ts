import { describe, expect, it } from "vitest";
import { computeStreaks } from "./streak";

const EVERY_DAY = [0, 1, 2, 3, 4, 5, 6];
const WEEKDAYS = [1, 2, 3, 4, 5];

describe("computeStreaks", () => {
  it("returns zero with no check-ins", () => {
    expect(
      computeStreaks({ daysOfWeek: EVERY_DAY, startDate: "2026-10-01", checkIns: [], today: "2026-10-10" }),
    ).toEqual({ current: 0, longest: 0 });
  });

  it("counts consecutive days including today", () => {
    const r = computeStreaks({
      daysOfWeek: EVERY_DAY,
      startDate: "2026-10-01",
      checkIns: ["2026-10-08", "2026-10-09", "2026-10-10"],
      today: "2026-10-10",
    });
    expect(r).toEqual({ current: 3, longest: 3 });
  });

  it("does not break the streak when today is still unchecked", () => {
    const r = computeStreaks({
      daysOfWeek: EVERY_DAY,
      startDate: "2026-10-01",
      checkIns: ["2026-10-08", "2026-10-09"],
      today: "2026-10-10",
    });
    expect(r.current).toBe(2);
  });

  it("breaks the streak after a missed scheduled day", () => {
    const r = computeStreaks({
      daysOfWeek: EVERY_DAY,
      startDate: "2026-10-01",
      checkIns: ["2026-10-01", "2026-10-02", "2026-10-03", "2026-10-06", "2026-10-07"],
      today: "2026-10-07",
    });
    expect(r).toEqual({ current: 2, longest: 3 });
  });

  it("skips unscheduled days without breaking the streak", () => {
    // 2026-10-09 is a Friday, 2026-10-12 is the following Monday.
    const r = computeStreaks({
      daysOfWeek: WEEKDAYS,
      startDate: "2026-10-05",
      checkIns: ["2026-10-08", "2026-10-09", "2026-10-12"],
      today: "2026-10-12",
    });
    expect(r.current).toBe(3);
  });

  it("ignores check-ins on unscheduled days", () => {
    // 2026-10-10 is a Saturday.
    const r = computeStreaks({
      daysOfWeek: WEEKDAYS,
      startDate: "2026-10-05",
      checkIns: ["2026-10-09", "2026-10-10"],
      today: "2026-10-12",
    });
    expect(r.current).toBe(1);
  });

  it("does not look before the start date", () => {
    const r = computeStreaks({
      daysOfWeek: EVERY_DAY,
      startDate: "2026-10-10",
      checkIns: ["2026-10-10"],
      today: "2026-10-10",
    });
    expect(r).toEqual({ current: 1, longest: 1 });
  });
});
