import type { CheckIn, Habit } from "@prisma/client";
import { toStr } from "./dates";

export type HabitView = {
  id: string;
  title: string;
  description: string | null;
  daysOfWeek: number[];
  startDate: string;
  checkIns: string[];
};

export function toView(h: Habit & { checkIns: Pick<CheckIn, "date">[] }): HabitView {
  return {
    id: h.id,
    title: h.title,
    description: h.description,
    daysOfWeek: h.daysOfWeek,
    startDate: toStr(h.startDate),
    checkIns: h.checkIns.map((c) => toStr(c.date)),
  };
}

export const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
/** Display order for the weekday picker (Monday first) */
export const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0];

export function scheduleLabel(days: number[]): string {
  const s = [...days].sort((a, b) => a - b);
  const key = s.join(",");
  if (s.length === 7) return "Every day";
  if (key === "1,2,3,4,5") return "Weekdays";
  if (key === "0,6") return "Weekends";
  return DAY_ORDER.filter((d) => s.includes(d))
    .map((d) => DAY_NAMES[d])
    .join(", ");
}
