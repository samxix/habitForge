"use client";

import { useFormStatus } from "react-dom";

export function SubmitButton({ children, pending: label }: { children: React.ReactNode; pending?: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending} className="btn">
      {pending ? (label ?? "Saving…") : children}
    </button>
  );
}
