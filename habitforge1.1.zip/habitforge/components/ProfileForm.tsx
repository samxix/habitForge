"use client";

import { useActionState } from "react";
import { updateProfile } from "@/actions/auth";
import { SubmitButton } from "./SubmitButton";

export function ProfileForm({
  name,
  email,
  timezone,
  timezones,
}: {
  name: string;
  email: string;
  timezone: string;
  timezones: string[];
}) {
  const [state, action] = useActionState(updateProfile, undefined);
  return (
    <form action={action} className="space-y-4">
      <label className="block space-y-1.5 text-sm font-medium">
        Email
        <input value={email} disabled className="field opacity-60" readOnly />
      </label>
      <label className="block space-y-1.5 text-sm font-medium">
        Name
        <input name="name" required defaultValue={name} className="field" />
      </label>
      <label className="block space-y-1.5 text-sm font-medium">
        Timezone
        <select name="timezone" defaultValue={timezone} className="field">
          {timezones.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
        <span className="block text-xs font-normal text-zinc-500">
          Decides when your day starts and ends for check-ins and streaks.
        </span>
      </label>
      {state?.error && (
        <p role="alert" className="text-sm text-red-600 dark:text-red-400">
          {state.error}
        </p>
      )}
      {state?.ok && (
        <p role="status" className="text-sm text-emerald-600 dark:text-emerald-400">
          Profile saved.
        </p>
      )}
      <SubmitButton>Save profile</SubmitButton>
    </form>
  );
}
