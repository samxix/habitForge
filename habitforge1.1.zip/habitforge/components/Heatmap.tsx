import { addDays, formatDay, weekday } from "@/lib/dates";

const LEVELS = [
  "bg-zinc-200 dark:bg-zinc-800",
  "bg-amber-200 dark:bg-amber-900",
  "bg-amber-300 dark:bg-amber-700",
  "bg-amber-500 dark:bg-amber-500",
  "bg-orange-600 dark:bg-orange-400",
];

export function levelFor(count: number, max: number) {
  if (count <= 0 || max <= 0) return 0;
  return Math.min(4, Math.ceil((count / max) * 4));
}

/**
 * Calendar heatmap. `data` maps YYYY-MM-DD to a count; `max` is the count that
 * should render as the hottest cell (e.g. the number of habits).
 */
export function Heatmap({
  data,
  max,
  end,
  weeks = 26,
  unit = "check-ins",
}: {
  data: Record<string, number>;
  max: number;
  end: string;
  weeks?: number;
  unit?: string;
}) {
  const start = addDays(end, -weekday(end) - (weeks - 1) * 7);
  const days: string[] = [];
  for (let d = start; d <= end; d = addDays(d, 1)) days.push(d);

  return (
    <div className="overflow-x-auto pb-1">
      <div
        role="img"
        aria-label={`Heatmap of ${unit} over the last ${weeks} weeks`}
        className="grid w-max grid-flow-col gap-[3px]"
        style={{ gridTemplateRows: "repeat(7, 12px)", gridAutoColumns: "12px" }}
      >
        {days.map((d) => {
          const count = data[d] ?? 0;
          return (
            <div
              key={d}
              title={`${formatDay(d, { month: "short", day: "numeric", year: "numeric" })}: ${count} ${unit}`}
              className={`rounded-[3px] ${LEVELS[levelFor(count, max)]}`}
            />
          );
        })}
      </div>
      <div className="mt-3 flex items-center gap-1.5 text-xs text-zinc-500">
        <span>Less</span>
        {LEVELS.map((c) => (
          <span key={c} className={`h-3 w-3 rounded-[3px] ${c}`} />
        ))}
        <span>More</span>
      </div>
    </div>
  );
}
