"use client";

import { useOptimistic, useTransition } from "react";
import { toggleCheckIn } from "@/actions/habits";

export function HabitToggle({
  habitId,
  date,
  done,
  title,
}: {
  habitId: string;
  date: string;
  done: boolean;
  title: string;
}) {
  const [optimisticDone, setOptimisticDone] = useOptimistic(done);
  const [, startTransition] = useTransition();

  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={optimisticDone}
      aria-label={`Mark ${title} as done`}
      onClick={() =>
        startTransition(async () => {
          setOptimisticDone(!optimisticDone);
          await toggleCheckIn(habitId, date);
        })
      }
      className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 transition ${
        optimisticDone
          ? "border-amber-500 bg-amber-500 text-zinc-950"
          : "border-zinc-300 hover:border-amber-500 dark:border-zinc-600"
      }`}
    >
      {optimisticDone && (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" aria-hidden>
          <path d="M5 12.5l4.5 4.5L19 7.5" />
        </svg>
      )}
    </button>
  );
}
