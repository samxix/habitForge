"use client";

import Link from "next/link";
import { useActionState } from "react";
import { DAY_NAMES, DAY_ORDER } from "@/lib/habits";
import type { FormState } from "@/lib/types";
import { SubmitButton } from "./SubmitButton";

export function HabitForm({
  action,
  initial,
}: {
  action: (state: FormState, fd: FormData) => Promise<FormState>;
  initial?: { title: string; description: string | null; daysOfWeek: number[] };
}) {
  const [state, formAction] = useActionState(action, undefined);
  const days = initial?.daysOfWeek ?? [0, 1, 2, 3, 4, 5, 6];

  return (
    <form action={formAction} className="space-y-5">
      <label className="block space-y-1.5 text-sm font-medium">
        Habit name
        <input
          name="title"
          required
          maxLength={80}
          defaultValue={initial?.title}
          placeholder="Read for 20 minutes"
          className="field"
        />
      </label>
      <label className="block space-y-1.5 text-sm font-medium">
        Notes (optional)
        <textarea
          name="description"
          rows={2}
          maxLength={300}
          defaultValue={initial?.description ?? ""}
          className="field"
        />
      </label>
      <fieldset className="space-y-2">
        <legend className="text-sm font-medium">Repeat on</legend>
        <div className="flex flex-wrap gap-2">
          {DAY_ORDER.map((d) => (
            <label key={d} className="cursor-pointer">
              <input type="checkbox" name="days" value={d} defaultChecked={days.includes(d)} className="peer sr-only" />
              <span className="block rounded-lg border border-zinc-300 px-3 py-1.5 text-sm transition peer-checked:border-amber-500 peer-checked:bg-amber-500 peer-checked:text-zinc-950 peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-amber-500 dark:border-zinc-700">
                {DAY_NAMES[d]}
              </span>
            </label>
          ))}
        </div>
      </fieldset>
      {state?.error && (
        <p role="alert" className="text-sm text-red-600 dark:text-red-400">
          {state.error}
        </p>
      )}
      <div className="flex gap-2">
        <SubmitButton>{initial ? "Save changes" : "Create habit"}</SubmitButton>
        <Link href="/habits" className="btn-quiet">
          Cancel
        </Link>
      </div>
    </form>
  );
}
