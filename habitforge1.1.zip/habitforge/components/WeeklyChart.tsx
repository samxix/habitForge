"use client";

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

type Point = { label: string; rate: number; completed: number; due: number };

export function WeeklyChart({ data }: { data: Point[] }) {
  return (
    <div className="h-64 w-full text-zinc-500" role="img" aria-label="Weekly completion rate for the last 8 weeks">
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke="currentColor" strokeOpacity={0.15} />
          <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "currentColor", fontSize: 12 }} />
          <YAxis
            domain={[0, 100]}
            tickFormatter={(v) => `${v}%`}
            tickLine={false}
            axisLine={false}
            tick={{ fill: "currentColor", fontSize: 12 }}
          />
          <Tooltip
            cursor={{ fill: "currentColor", fillOpacity: 0.08 }}
            formatter={(value, _name, item) => [
              `${value}% (${item.payload.completed} of ${item.payload.due})`,
              "Completed",
            ]}
            labelFormatter={(l) => `Week of ${l}`}
            contentStyle={{ borderRadius: 8, fontSize: 13 }}
          />
          <Bar dataKey="rate" fill="#f59e0b" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
