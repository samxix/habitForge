"use client";

import Link from "next/link";
import { useActionState, useEffect, useRef } from "react";
import { login, register } from "@/actions/auth";
import { SubmitButton } from "./SubmitButton";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const isRegister = mode === "register";
  const [state, action] = useActionState(isRegister ? register : login, undefined);
  const tz = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (tz.current) tz.current.value = Intl.DateTimeFormat().resolvedOptions().timeZone;
  }, []);

  return (
    <form action={action} className="space-y-4">
      {isRegister && (
        <label className="block space-y-1.5 text-sm font-medium">
          Name
          <input name="name" required autoComplete="name" className="field" />
        </label>
      )}
      <label className="block space-y-1.5 text-sm font-medium">
        Email
        <input name="email" type="email" required autoComplete="email" className="field" />
      </label>
      <label className="block space-y-1.5 text-sm font-medium">
        Password
        <input
          name="password"
          type="password"
          required
          minLength={isRegister ? 8 : undefined}
          autoComplete={isRegister ? "new-password" : "current-password"}
          className="field"
        />
      </label>
      {isRegister && <input ref={tz} type="hidden" name="timezone" />}
      {state?.error && (
        <p role="alert" className="text-sm text-red-600 dark:text-red-400">
          {state.error}
        </p>
      )}
      <SubmitButton pending={isRegister ? "Creating account…" : "Signing in…"}>
        {isRegister ? "Create account" : "Sign in"}
      </SubmitButton>
      <p className="text-sm text-zinc-500">
        {isRegister ? "Already have an account? " : "New to HabitForge? "}
        <Link href={isRegister ? "/login" : "/register"} className="font-medium text-zinc-900 underline dark:text-zinc-100">
          {isRegister ? "Sign in" : "Create an account"}
        </Link>
      </p>
    </form>
  );
}
